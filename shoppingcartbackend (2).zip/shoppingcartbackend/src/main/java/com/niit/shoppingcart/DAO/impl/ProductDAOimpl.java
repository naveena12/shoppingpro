package com.niit.shoppingcart.DAO.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.Product;
import com.niit.shoppingcartDAO.ProductDAO;

@Repository("productDAO")
public class ProductDAOimpl implements ProductDAO {
	@Autowired
	SessionFactory sessionFactory;
	public ProductDAOimpl(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}
	
    @Transactional
	public boolean save(Product product) {
    	try {
			sessionFactory.getCurrentSession().save(product);
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		
		// TODO Auto-generated method stub
		return false;
	}}
    @Transactional
	public boolean update(Product product) {
    	try {
			sessionFactory.getCurrentSession().update(product);
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		// TODO Auto-generated method stub
		return false;
	}}
    @Transactional
	public boolean delete(Product product) {
    	try {
			sessionFactory.getCurrentSession().delete(product);
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		// TODO Auto-generated method stub
		return false;
	}}
    @Transactional
	public Product get(String id) {
    	{
    		String hql="from Product where id='"+id+"'";
    		 List<Product> li=sessionFactory.getCurrentSession().createQuery(hql).list();
    		 if(li==null||li.isEmpty())
    			 return null;
    		 else
    			 return li.get(0);
    	
		// TODO Auto-generated method stub
    	}
	}
     @Transactional
	public List<Product> list() {
    	
    		   String hql ="from Product";
    		   List<Product> li=sessionFactory.getCurrentSession().createQuery(hql).list();
    			// TODO Auto-generated method stub
    			return li;
    	   	
    		}
		// TODO Auto-generated method stub
	
	
	
	

}
