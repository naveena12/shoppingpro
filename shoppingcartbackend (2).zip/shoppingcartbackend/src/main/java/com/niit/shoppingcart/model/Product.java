package com.niit.shoppingcart.model;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;

import org.springframework.stereotype.Component;
@Entity
@Table(name="product")
@Component

public class Product {
	@Id
	private String Id;
	private String Name;
	private String Price;
	private String Category_id;
	private String Supplier_id;
	private String Description;
	
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPrice() {
		return Price;
	}
	public void setPrice(String price) {
		Price = price;
	}
	public String getCategory_id() {
		return Category_id;
	}
	public void setCategory_id(String category_id) {
		Category_id = category_id;
	}
	public String getSupplier_id() {
		return Supplier_id;
	}
	public void setSupplier_id(String supplier_id) {
		Supplier_id = supplier_id;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	
	
	

}
