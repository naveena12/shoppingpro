package com.niit.shoppingcartbackend;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcartDAO.CartDAO;


public class testCart {
public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		CartDAO cartDAO = (CartDAO) context.getBean("cartDAO");
		Cart cart = (Cart) context.getBean("cart");
		cart.setId("101");
		 cart.setOrder_Id("123");
		 cart.setBilling_address_id("78392");
		 cart.setShiping_address_id("1234");
		 cart.setPaymentmethod("debitcard");
		 
		 
		 
		System.out.println(cartDAO.save(cart));
			//cartDAO.delete(cart);
		//cartDAO.update(cart);
				//System.out.println("Data deleted in DB");
		        System.out.println("data inserted in db");
			//System.out.println("data updated");
			//List<Cart> clist=cartDAO.list();
			//for(Cart c:clist)
			//{
				
				//System.out.println("Cart id:"+c.getOrder_Id());
			//}
			
			}
			
			

}
