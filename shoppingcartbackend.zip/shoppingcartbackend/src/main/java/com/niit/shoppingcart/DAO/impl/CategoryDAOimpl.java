package com.niit.shoppingcart.DAO.impl;


import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcartDAO.CategoryDAO;

@Repository("categoryDAO")
public class CategoryDAOimpl implements CategoryDAO {
	@Autowired
	SessionFactory sessionFactory;
	public CategoryDAOimpl(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}
  @Transactional
	public boolean save(Category category) {
		try {
			if ( get(category.getId())!=null)
					{
				      return false;
					}
			//sessionFactory.getCurrentSession()
			sessionFactory.getCurrentSession().save(category);
			System.out.println("Data Inserted....."
					+ "+");
			return true;
		} catch ( HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
			return false;
	}}
 
  
  
  //@Transactional
  //public void saveCat(Category category)
  //{
//	  sessionFactory.getCurrentSession().save(category);
	//  System.out.println("Data Inserted.....");
  //}
	@Transactional
	public boolean delete(Category category) {
		try {
		
			sessionFactory.getCurrentSession().delete(category);
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		// TODO Auto-generated method stub
		return false;
	}
	}
	@Transactional
	public Category get(String id) 
	{
		String hql="from Category where id='"+id+"'";
	 List<Category> li=sessionFactory.getCurrentSession().createQuery(hql).list();
	 if(li==null||li.isEmpty())
		 return null;
	 else
		 return li.get(0);
		 
		// TODO Auto-generated method stub
		
	}
   @Transactional
	public List<Category> list( ) {
	   String hql ="from Category";
	   List<Category> li=sessionFactory.getCurrentSession().createQuery(hql).list();
		// TODO Auto-generated method stub
		return li;
   	
	}
//	public boolean save(Category category){
//		try {
//			sessionFactory.getcurrentsession().save(category);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return false;
//	}
//
//	public boolean update(Category category){
//		try {
//			sessionFactory.getcurrentsession().update(category);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return false;
//	}
//	public boolean delete(Category category){
//		try {
//			sessionFactory.getcurrentsession().delete(category);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return false;
//	}
//	public Category get(String id){
//		sessionFactory.getcurrentsession().delete(category);
//		return null;
//	}
//	public List <Category> List(){
//		return null;
//	}
	@Transactional
	public boolean update(Category category) {
		try {
			sessionFactory.getCurrentSession().update(category);
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		// TODO Auto-generated method stub
		return false;
	}
  }
}
  

