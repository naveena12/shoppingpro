package com.niit.shoppingcart.DAO.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.model.Cart;

import com.niit.shoppingcartDAO.CartDAO;

@Repository("CartDAO")
public class CartDAOimpl  implements CartDAO {
 @Autowired
 SessionFactory sessionFactory;
 public CartDAOimpl(SessionFactory ssessionFactory)
 {
	 this.sessionFactory=sessionFactory;
 }
  @Transactional
	public boolean save(Cart cart) {
	  try {
		sessionFactory.getCurrentSession().save(cart);
		return true;
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	
		// TODO Auto-generated method stub
		return false;
	}}
 @Transactional
	public boolean update(Cart cart) {
	 try {
		sessionFactory.getCurrentSession().update(cart);
		return true;
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	
		// TODO Auto-generated method stub
		return false;
	}}
 @Transactional
	public boolean delete(Cart cart) {
	 try {
		sessionFactory.getCurrentSession().delete(cart);
		return true;
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	
		// TODO Auto-generated method stub
		return false;
	}}
 @Transactional
	public Cart get(String id) {
	 String hql="from Cart where id='"+id+"'";
	 List<Cart> li=sessionFactory.getCurrentSession().createQuery(hql).list();
	 if(li==null||li.isEmpty())
		 return null;
	 else
		 return li.get(0);

		// TODO Auto-generated method stub
 
	}
 @Transactional
	public List<Cart> list() {
	 String hql ="from Cart";
	   List<Cart> li=sessionFactory.getCurrentSession().createQuery(hql).list();
		// TODO Auto-generated method stub
		return li;
 	
		// TODO Auto-generated method stub
		
	}

}
