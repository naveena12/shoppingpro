package com.niit.shoppingcart.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table
@Component
public class Cart {
	@Id
	private String id;
	private String Order_Id;
	private String billing_address_id;
	private String shiping_address_id;
	private String paymentmethod;
	

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getOrder_Id() {
		return Order_Id;
	}
	public void setOrder_Id(String order_Id) {
		Order_Id = order_Id;
	}
	public String getBilling_address_id() {
		return billing_address_id;
	}
	public void setBilling_address_id(String billing_address_id) {
		this.billing_address_id = billing_address_id;
	}
	public String getShiping_address_id() {
		return shiping_address_id;
	}
	public void setShiping_address_id(String shiping_address_id) {
		this.shiping_address_id = shiping_address_id;
	}
	public String getPaymentmethod() {
		return paymentmethod;
	}
	public void setPaymentmethod(String paymentmethod) {
		this.paymentmethod = paymentmethod;
	}
}
	
	


