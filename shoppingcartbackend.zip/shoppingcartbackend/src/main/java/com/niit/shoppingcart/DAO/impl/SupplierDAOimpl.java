package com.niit.shoppingcart.DAO.impl;

import java.util.List;


import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.model.Supplier;
import com.niit.shoppingcartDAO.SupplierDAO;

@Repository("supplierDAO")
public class SupplierDAOimpl implements SupplierDAO {
@Autowired
SessionFactory sessionFactory;
public SupplierDAOimpl(SessionFactory sessionFactory)
{
	this.sessionFactory=sessionFactory;
}
 @Transactional
	public boolean save(Supplier supplier) {
	 try {
		
		sessionFactory.getCurrentSession().save(supplier);
		return true;
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	
		// TODO Auto-generated method stub
		return false;
	}}
 @Transactional
	public boolean update(Supplier supplier) {
		// TODO Auto-generated method stub
	 try {
		sessionFactory.getCurrentSession().update(supplier);
		return true;
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return false;
	}
 }
 @Transactional
	public boolean delete(Supplier supplier) {
		// TODO Auto-generated method stub
	 try {
		sessionFactory.getCurrentSession().delete(supplier);
		return true;
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	
		return false;
	}
	 }
 @Transactional
	public Supplier get(String id) {
	 String hql="from String where id='"+id+"'";
	 List<Supplier> li=sessionFactory.getCurrentSession().createQuery(hql).list();
	 if(li==null||li.isEmpty())
		 return null;
	 else
		 return li.get(0);
 
		// TODO Auto-generated method stub
		
	}
 @Transactional
	public List<Supplier> list() {
	 String hql ="from Supplier";
	   List<Supplier> li=sessionFactory.getCurrentSession().createQuery(hql).list();
		// TODO Auto-generated method stub
		return li;
 	
	
		// TODO Auto-generated method stub
	
	}


}
